process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
require('dotenv').config();

const express  = require('express');
const session  = require('express-session');
const { Issuer, generators } = require('openid-client');
const fetch    = require('node-fetch');
const http     = require('http');
const path     = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;
const BACKEND_URL = process.env.BACKEND_URL || 'http://backend-service:4000';
const DRAWIO_URL  = process.env.DRAWIO_URL  || 'http://drawio-service:8080';

const {
  OAUTH_CLIENT_ID,
  OAUTH_CLIENT_SECRET,
  OPENID_PROVIDER_URL,
  OPENID_REDIRECT_URI,
  WEBUI_AUTH_SIGNOUT_REDIRECT_URL,
  WEBUI_URL,
  LOG_LEVEL,
  ADMIN_USERNAME,
  ADMIN_PASSWORD,
} = process.env;

const log = (...args) => { if (LOG_LEVEL === 'debug') console.log('[DEBUG]', ...args); };

// ── MIDDLEWARE ─────────────────────────────────────────────
app.use(session({
  secret: OAUTH_CLIENT_SECRET || 'note-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 8 * 60 * 60 * 1000 },
}));

// urlencoded ÖNCE tanımlanmalı (admin-login POST için)
app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));
// Quill statik dosyaları (internet olmayan ortamlar için npm'den serve edilir)
app.use('/vendor/quill', express.static(path.join(__dirname, 'node_modules/quill/dist')));

// ── OIDC ───────────────────────────────────────────────────
let oidcClient;
async function initOIDC() {
  try {
    const issuer = await Issuer.discover(OPENID_PROVIDER_URL);
    oidcClient = new issuer.Client({
      client_id:      OAUTH_CLIENT_ID,
      client_secret:  OAUTH_CLIENT_SECRET,
      redirect_uris:  [OPENID_REDIRECT_URI],
      response_types: ['code'],
    });
    log('OIDC hazır');
  } catch (err) {
    console.error('OIDC init hatası:', err.message);
    setTimeout(initOIDC, 5000);
  }
}

// ── AUTH ───────────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.session.user) return next();
  if (req.path.startsWith('/api/') || req.path.startsWith('/drawio')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  res.redirect('/login');
}

// ── BACKEND PROXY ──────────────────────────────────────────
// Türkçe/özel karakter içeren header değerlerini base64 encode et
function encodeHeader(val) {
  if (!val) return '';
  return Buffer.from(String(val), 'utf8').toString('base64');
}

async function proxyToBackend(req, res) {
  try {
    const qs  = req.url.includes('?') ? '?' + req.url.split('?')[1] : '';
    const url = `${BACKEND_URL}${req.path}${qs}`;
    const options = {
      method: req.method,
      headers: {
        'Content-Type':    'application/json',
        'X-User-Email':    encodeHeader(req.session.user.email),
        'X-User-Name':     encodeHeader(req.session.user.name),
        'X-User-Groups':   encodeHeader(JSON.stringify(req.session.user.groups || [])),
        'X-User-Encoding': 'base64',
        'X-Super-Admin':   req.session.user.isSuperAdmin ? '1' : '0',
      },
    };
    if (req.method !== 'GET' && req.body) {
      options.body = JSON.stringify(req.body);
    }
    const backendRes = await fetch(url, options);
    const data = await backendRes.json();
    res.status(backendRes.status).json(data);
  } catch (err) {
    console.error('Backend proxy hatası:', err.message);
    res.status(502).json({ error: 'Backend ulaşılamıyor' });
  }
}

// ── ROUTES ─────────────────────────────────────────────────

app.get('/', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Süper admin login sayfası
app.get('/admin-login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-login.html'));
});

// Süper admin login POST
app.post('/admin-login', (req, res) => {
  const { username, password } = req.body;
  log('Admin login denemesi:', username);
  if (
    ADMIN_USERNAME && ADMIN_PASSWORD &&
    username === ADMIN_USERNAME &&
    password === ADMIN_PASSWORD
  ) {
    req.session.user = {
      name:        'Süper Admin',
      email:       ADMIN_USERNAME,
      groups:      [],
      isSuperAdmin: true,
    };
    log('Admin login başarılı');
    return res.redirect('/');
  }
  log('Admin login başarısız');
  res.redirect('/admin-login?error=1');
});

// Keycloak login
app.get('/login', (req, res) => {
  if (!oidcClient) return res.status(503).send('Sistem hazırlanıyor, sayfayı yenileyin.');
  const nonce = generators.nonce();
  const state = generators.state();
  req.session.nonce = nonce;
  req.session.state = state;
  const authUrl = oidcClient.authorizationUrl({ scope: 'openid email profile', nonce, state });
  log('Login redirect:', authUrl);
  res.redirect(authUrl);
});

// OIDC callback
app.get(['/callback', '/oauth/oidc/callback'], async (req, res) => {
  try {
    const params   = oidcClient.callbackParams(req);
    const tokenSet = await oidcClient.callback(OPENID_REDIRECT_URI, params, {
      nonce: req.session.nonce,
      state: req.session.state,
    });
    const userinfo = await oidcClient.userinfo(tokenSet.access_token);
    log('Login başarılı:', userinfo.email, 'gruplar:', userinfo.groups);
    req.session.user = {
      name:     userinfo.name || userinfo.preferred_username,
      email:    userinfo.email,
      groups:   userinfo.groups || [],
      id_token: tokenSet.id_token,
    };
    res.redirect('/');
  } catch (err) {
    console.error('Callback hatası:', err.message);
    res.redirect('/login');
  }
});

// Kullanıcı bilgisi
app.get('/api/me', requireAuth, (req, res) => {
  res.json({
    name:         req.session.user.name,
    email:        req.session.user.email,
    groups:       req.session.user.groups || [],
    isSuperAdmin: req.session.user.isSuperAdmin || false,
  });
});

// Grup konfigürasyonu
app.get('/api/groups', requireAuth, (req, res) => {
  let groupConfig = {};
  try { groupConfig = JSON.parse(process.env.GROUP_CONFIG || '{}'); } catch(_) {}
  res.json({
    groups:     groupConfig,
    adminGroup: process.env.ADMIN_GROUP || 'BTAOM_YONETICILER',
  });
});

// Backend proxy
app.all('/api/notes*',  requireAuth, proxyToBackend);
app.all('/api/admin*',  requireAuth, proxyToBackend);
app.all('/api/export*', requireAuth, proxyToBackend);

// Import: multipart proxy
app.post('/api/import/xar', requireAuth, (req, res) => {
  const parsed = new URL(BACKEND_URL);
  const proxyReq = http.request({
    hostname: parsed.hostname,
    port:     parsed.port || 4000,
    path:     '/api/import/xar',
    method:   'POST',
    headers: {
      'content-type':    req.headers['content-type'],
      'X-User-Email':    encodeHeader(req.session.user.email),
      'X-User-Name':     encodeHeader(req.session.user.name),
      'X-User-Groups':   encodeHeader(JSON.stringify(req.session.user.groups || [])),
      'X-User-Encoding': 'base64',
      'X-Super-Admin':   req.session.user.isSuperAdmin ? '1' : '0',
    },
  }, (backendRes) => {
    res.status(backendRes.statusCode);
    backendRes.pipe(res);
  });
  proxyReq.on('error', () => res.status(502).json({ error: 'Backend ulaşılamıyor' }));
  req.pipe(proxyReq);
});

// ── DRAW.IO PROXY ──────────────────────────────────────────
// draw.io tüm statik dosyalarını /drawio/* üzerinden proxy'ler
app.use('/drawio', requireAuth, (req, res) => {
  const parsed   = new URL(DRAWIO_URL);
  const hostname = parsed.hostname;
  const port     = parseInt(parsed.port) || 8080;
  // draw.io kendi içinde absolute path kullanır, req.url olduğu gibi iletilir
  const proxyPath = req.url || '/';

  const proxyReq = http.request(
    { hostname, port, path: proxyPath, method: req.method, headers: { host: `${hostname}:${port}` } },
    (proxyRes) => {
      const headers = {};
      for (const [k, v] of Object.entries(proxyRes.headers)) {
        // iframe'de çalışması için bu header'ları kaldır
        if (['x-frame-options','content-security-policy','x-content-type-options'].includes(k.toLowerCase())) continue;
        headers[k] = v;
      }
      res.writeHead(proxyRes.statusCode, headers);
      proxyRes.pipe(res, { end: true });
    }
  );
  proxyReq.on('error', (e) => {
    console.error('Draw.io proxy hatası:', e.message);
    if (!res.headersSent) res.status(502).send('Draw.io servisine ulaşılamıyor');
  });
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    req.pipe(proxyReq, { end: true });
  } else {
    proxyReq.end();
  }
});

// ── LOGOUT ─────────────────────────────────────────────────
app.get('/logout', (req, res) => {
  const idToken    = req.session.user?.id_token;
  const superAdmin = req.session.user?.isSuperAdmin;
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    if (superAdmin) {
      return res.redirect('/admin-login');
    }
    // Keycloak endSessionUrl dene, olmazsa direkt /login
    if (oidcClient && idToken) {
      try {
        const logoutUrl = oidcClient.endSessionUrl({
          id_token_hint:            idToken,
          post_logout_redirect_uri: WEBUI_AUTH_SIGNOUT_REDIRECT_URL
            || (WEBUI_URL ? `${WEBUI_URL}/login` : `http://localhost:${PORT}/login`),
        });
        return res.redirect(logoutUrl);
      } catch(e) {
        console.error('Logout URL hatası:', e.message);
      }
    }
    res.redirect('/login');
  });
});

// Debug
app.get('/debug/token', requireAuth, (req, res) => {
  res.json({ name: req.session.user.name, email: req.session.user.email, groups: req.session.user.groups });
});

// ── START ──────────────────────────────────────────────────
initOIDC().then(() => {
  app.listen(PORT, () => console.log(`Frontend çalışıyor: http://localhost:${PORT}`));
});
