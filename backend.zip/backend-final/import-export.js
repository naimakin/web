/**
 * import-export.js
 * XAR import, HTML/JSON/Markdown/PDF export endpoint'leri
 */

const express   = require('express');
const router    = express.Router();
const path      = require('path');
const fs        = require('fs');
const os        = require('os');
const AdmZip    = require('adm-zip');
const { pool }  = require('./db');
const { requireAuth, canRead, KNOWN_GROUPS } = require('./auth');
const { parseXmlDocument, xwikiToHtml } = require('./xwiki-parser');

// ── IMPORT: XAR ─────────────────────────────────────────────────────────────

/**
 * POST /api/import/xar
 * Body: multipart/form-data, field: "file" (XAR dosyası), "target_group" (hangi gruba aktarılsın)
 */
router.post('/xar', requireAuth, async (req, res) => {
  // Sadece admin veya grup üyesi import yapabilir
  if (!req.user.isAdmin && !req.user.isSuperAdmin && req.user.groups.length === 0) {
    return res.status(403).json({ error: 'Import yetkisi yok' });
  }

  const chunks = [];
  req.on('data', chunk => chunks.push(chunk));
  req.on('end', async () => {
    try {
      // Multipart parse — basit boundary parser
      const body = Buffer.concat(chunks);
      const boundary = req.headers['content-type'].split('boundary=')[1];
      const parts = parseMultipart(body, boundary);

      const filePart    = parts.find(p => p.name === 'file');
      const groupPart   = parts.find(p => p.name === 'target_group');
      const titlePrefix = parts.find(p => p.name === 'title_prefix');

      if (!filePart) return res.status(400).json({ error: 'XAR dosyası bulunamadı' });

      const targetGroup = groupPart
        ? groupPart.data.toString().trim()
        : (req.user.groups[0] || KNOWN_GROUPS[0]);

      // Kullanıcı hedef grubun üyesi mi?
      if (!req.user.isAdmin && !req.user.isSuperAdmin && !req.user.groups.includes(targetGroup)) {
        return res.status(403).json({ error: 'Bu gruba import yetkisi yok' });
      }

      // ZIP aç
      const zip = new AdmZip(filePart.data);
      const zipEntries = zip.getEntries();

      const results = { imported: 0, skipped: 0, errors: [] };

      for (const entry of zipEntries) {
        // package.xml ve klasör girdilerini atla
        if (entry.entryName === 'package.xml' || entry.isDirectory) continue;
        if (!entry.entryName.endsWith('.xml')) continue;

        try {
          const xmlContent = entry.getData().toString('utf8');
          const parsed = parseXmlDocument(xmlContent);

          // Başlık prefix'i varsa ekle (ör: "XWiki Import - ")
          const prefix = titlePrefix ? titlePrefix.data.toString().trim() : '';
          const noteTitle = prefix ? `${prefix}${parsed.title}` : parsed.title;

          // Not içeriğine breadcrumb bilgisi ekle
          const fullContent = parsed.breadcrumb
            ? `<p style="color:#888;font-size:0.8em;margin-bottom:16px">📁 ${parsed.breadcrumb}</p>${parsed.content}`
            : parsed.content;

          await pool.query(
            `INSERT INTO notes (title, content, owner_group, created_by, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [noteTitle, fullContent, targetGroup, req.user.email, parsed.created_at, parsed.updated_at]
          );
          results.imported++;
        } catch(e) {
          results.errors.push({ file: entry.entryName, error: e.message });
          results.skipped++;
        }
      }

      res.json({
        ok: true,
        message: `${results.imported} not içe aktarıldı, ${results.skipped} atlandı.`,
        ...results,
      });
    } catch(e) {
      console.error('XAR import hatası:', e.message);
      res.status(500).json({ error: 'Import başarısız: ' + e.message });
    }
  });
});

// ── EXPORT: Tek Not ──────────────────────────────────────────────────────────

/**
 * GET /api/export/note/:id?format=html|json|md
 */
router.get('/note/:id', requireAuth, async (req, res) => {
  const { format = 'html' } = req.query;
  try {
    const result = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = result.rows[0];
    if (!canRead(req.user, note)) return res.status(403).json({ error: 'Erişim yetkisi yok' });

    const filename = sanitizeFilename(note.title);

    switch(format) {
      case 'json':
        res.setHeader('Content-Disposition', `attachment; filename="${filename}.json"`);
        res.setHeader('Content-Type', 'application/json');
        return res.json({ title: note.title, content: note.content, group: note.owner_group, exported_at: new Date().toISOString() });

      case 'md':
        res.setHeader('Content-Disposition', `attachment; filename="${filename}.md"`);
        res.setHeader('Content-Type', 'text/markdown');
        return res.send(htmlToMarkdown(note.title, note.content));

      case 'html':
      default:
        res.setHeader('Content-Disposition', `attachment; filename="${filename}.html"`);
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        return res.send(wrapHtml(note.title, note.content));
    }
  } catch(e) {
    res.status(500).json({ error: 'Export başarısız' });
  }
});

/**
 * GET /api/export/group/:group?format=html|json|md
 * Tüm grubun notlarını ZIP olarak indir
 */
router.get('/group/:group', requireAuth, async (req, res) => {
  const { format = 'html' } = req.query;
  const group = req.params.group;

  // Yetki: kendi grubu veya admin
  if (!req.user.isAdmin && !req.user.isSuperAdmin && !req.user.groups.includes(group)) {
    return res.status(403).json({ error: 'Bu grubun export yetkisi yok' });
  }

  try {
    const result = await pool.query(
      'SELECT * FROM notes WHERE owner_group = $1 ORDER BY updated_at DESC',
      [group]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Bu grupta not bulunamadı' });
    }

    const zip = new AdmZip();
    const groupLabel = sanitizeFilename(group);

    for (const note of result.rows) {
      const filename = sanitizeFilename(note.title);
      let fileContent, ext;

      switch(format) {
        case 'json':
          ext = 'json';
          fileContent = JSON.stringify({ title: note.title, content: note.content, group: note.owner_group, exported_at: new Date().toISOString() }, null, 2);
          break;
        case 'md':
          ext = 'md';
          fileContent = htmlToMarkdown(note.title, note.content);
          break;
        case 'html':
        default:
          ext = 'html';
          fileContent = wrapHtml(note.title, note.content);
      }

      zip.addFile(`${groupLabel}/${filename}.${ext}`, Buffer.from(fileContent, 'utf8'));
    }

    const zipBuffer = zip.toBuffer();
    res.setHeader('Content-Disposition', `attachment; filename="notes-${groupLabel}-${format}.zip"`);
    res.setHeader('Content-Type', 'application/zip');
    res.send(zipBuffer);
  } catch(e) {
    console.error('Group export hatası:', e.message);
    res.status(500).json({ error: 'Export başarısız' });
  }
});

// ── YARDIMCI FONKSİYONLAR ────────────────────────────────────────────────────

function wrapHtml(title, content) {
  return `<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8"/>
  <title>${escapeHtml(title)}</title>
  <style>
    body { font-family: -apple-system, sans-serif; max-width: 860px; margin: 40px auto; padding: 0 24px; line-height: 1.7; color: #222; }
    h1 { font-size: 2rem; border-bottom: 2px solid #eee; padding-bottom: 12px; }
    pre { background: #f6f8fa; padding: 16px; border-radius: 6px; overflow-x: auto; }
    code { background: #f0f0f0; padding: 2px 5px; border-radius: 3px; }
    table { border-collapse: collapse; width: 100%; }
    td, th { border: 1px solid #ddd; padding: 8px 12px; }
    th { background: #f0f4f8; }
    blockquote { border-left: 4px solid #4f8ef7; padding-left: 16px; color: #555; }
    mark { background: #fff3cd; padding: 1px 3px; }
    img { max-width: 100%; }
    .meta { color: #888; font-size: 0.85rem; margin-bottom: 24px; }
  </style>
</head>
<body>
  <h1>${escapeHtml(title)}</h1>
  <div class="meta">Dışa aktarıldı: ${new Date().toLocaleString('tr-TR')}</div>
  ${content}
</body>
</html>`;
}

function htmlToMarkdown(title, html) {
  let md = `# ${title}\n\n`;
  let content = html;

  // Basit HTML → Markdown dönüşümü
  content = content.replace(/<h1[^>]*>(.*?)<\/h1>/gi, '# $1\n');
  content = content.replace(/<h2[^>]*>(.*?)<\/h2>/gi, '## $1\n');
  content = content.replace(/<h3[^>]*>(.*?)<\/h3>/gi, '### $1\n');
  content = content.replace(/<h4[^>]*>(.*?)<\/h4>/gi, '#### $1\n');
  content = content.replace(/<strong[^>]*>(.*?)<\/strong>/gi, '**$1**');
  content = content.replace(/<b[^>]*>(.*?)<\/b>/gi, '**$1**');
  content = content.replace(/<em[^>]*>(.*?)<\/em>/gi, '*$1*');
  content = content.replace(/<i[^>]*>(.*?)<\/i>/gi, '*$1*');
  content = content.replace(/<code[^>]*>(.*?)<\/code>/gi, '`$1`');
  content = content.replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, '```\n$1\n```\n');
  content = content.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, '```\n$1\n```\n');
  content = content.replace(/<li[^>]*>(.*?)<\/li>/gi, '- $1\n');
  content = content.replace(/<ul[^>]*>|<\/ul>|<ol[^>]*>|<\/ol>/gi, '\n');
  content = content.replace(/<a[^>]*href="([^"]*)"[^>]*>(.*?)<\/a>/gi, '[$2]($1)');
  content = content.replace(/<img[^>]*src="([^"]*)"[^>]*alt="([^"]*)"[^>]*/gi, '![$2]($1)');
  content = content.replace(/<br\s*\/?>/gi, '\n');
  content = content.replace(/<p[^>]*>([\s\S]*?)<\/p>/gi, '$1\n\n');
  content = content.replace(/<hr\s*\/?>/gi, '\n---\n');
  content = content.replace(/<blockquote[^>]*>([\s\S]*?)<\/blockquote>/gi, (_, inner) =>
    inner.split('\n').map(l => `> ${l}`).join('\n')
  );
  content = content.replace(/<[^>]+>/g, ''); // kalan tag'leri temizle
  content = content.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ');
  content = content.replace(/\n{3,}/g, '\n\n').trim();

  return md + content;
}

function escapeHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function sanitizeFilename(name) {
  return (name || 'not').replace(/[/\\?%*:|"<>]/g, '-').replace(/\s+/g, '_').substring(0, 100);
}

// Basit multipart/form-data parser (Buffer tabanlı)
function parseMultipart(body, boundary) {
  const parts = [];
  const sep = Buffer.from(`--${boundary}`);
  const end = Buffer.from(`--${boundary}--`);

  let start = 0;
  while (start < body.length) {
    const sepIdx = indexOf(body, sep, start);
    if (sepIdx === -1) break;
    const headerStart = sepIdx + sep.length + 2; // \r\n sonrası
    if (body.slice(sepIdx, sepIdx + end.length).equals(end)) break;

    const headerEnd = indexOf(body, Buffer.from('\r\n\r\n'), headerStart);
    if (headerEnd === -1) break;

    const headerStr = body.slice(headerStart, headerEnd).toString();
    const nameMatch = headerStr.match(/name="([^"]+)"/);
    const filenameMatch = headerStr.match(/filename="([^"]+)"/);

    const dataStart = headerEnd + 4;
    const nextSep = indexOf(body, sep, dataStart);
    const dataEnd = nextSep === -1 ? body.length : nextSep - 2; // \r\n öncesi

    parts.push({
      name: nameMatch ? nameMatch[1] : '',
      filename: filenameMatch ? filenameMatch[1] : null,
      data: body.slice(dataStart, dataEnd),
    });
    start = nextSep === -1 ? body.length : nextSep;
  }
  return parts;
}

function indexOf(buf, search, offset = 0) {
  for (let i = offset; i <= buf.length - search.length; i++) {
    if (buf.slice(i, i + search.length).equals(search)) return i;
  }
  return -1;
}

module.exports = router;
