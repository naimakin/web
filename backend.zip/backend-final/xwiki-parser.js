/**
 * xwiki-parser.js
 * XAR (XWiki Archive) dosyasını parse edip Note Platform formatına çevirir.
 * XWiki 2.1 syntax → HTML dönüşümü yapar.
 */

const { DOMParser } = require('@xmldom/xmldom');

/**
 * XWiki 2.1 Syntax → HTML
 * Desteklenen: başlıklar, bold, italic, kod blokları, listeler, linkler, tablolar, mark
 */
function xwikiToHtml(text) {
  if (!text) return '';
  let html = text;

  // Satır sonlarını normalize et
  html = html.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

  // Kod blokları {{code language="..."}}...{{/code}}
  html = html.replace(/\{\{code[^}]*\}\}([\s\S]*?)\{\{\/code\}\}/g, (_, code) => {
    const escaped = code.trim()
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
    return `<pre><code>${escaped}</code></pre>`;
  });

  // Diğer makrolar {{...}}...{{/...}} → kaldır veya içeriği al
  html = html.replace(/\{\{[^}]+\}\}([\s\S]*?)\{\{\/[^}]+\}\}/g, '$1');
  html = html.replace(/\{\{[^}]+\}\}/g, '');

  // Parametreli stil blokları (% class="mark" %)...(%%): <mark> yap
  html = html.replace(/\(%\s*class="mark"\s*%\)(.*?)(?=\n|$)/g, '<mark>$1</mark>');
  // Kalan (% ... %) bloklarını temizle
  html = html.replace(/\(%[^%]*%\)/g, '');
  html = html.replace(/%%/g, '');

  // Başlıklar: ==== ... ==== (önce uzunları işle)
  html = html.replace(/^======\s*(.*?)\s*======\s*$/gm, '<h6>$1</h6>');
  html = html.replace(/^=====\s*(.*?)\s*=====\s*$/gm,  '<h5>$1</h5>');
  html = html.replace(/^====\s*(.*?)\s*====\s*$/gm,    '<h4>$1</h4>');
  html = html.replace(/^===\s*(.*?)\s*===\s*$/gm,      '<h3>$1</h3>');
  html = html.replace(/^==\s*(.*?)\s*==\s*$/gm,        '<h2>$1</h2>');
  html = html.replace(/^=\s*(.*?)\s*=\s*$/gm,          '<h1>$1</h1>');

  // Bold + italic: **__text__**
  html = html.replace(/\*\*__(.*?)__\*\*/g, '<strong><em>$1</em></strong>');
  // Bold: **text**
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  // Italic: //text//
  html = html.replace(/\/\/(.*?)\/\//g, '<em>$1</em>');
  // Underline: __text__
  html = html.replace(/__(.*?)__/g, '<u>$1</u>');
  // Strikethrough: ~~text~~
  html = html.replace(/~~(.*?)~~/g, '<s>$1</s>');
  // Inline code: ##text##
  html = html.replace(/##(.*?)##/g, '<code>$1</code>');
  // Monospace: {{{{text}}}}
  html = html.replace(/\{\{\{\{(.*?)\}\}\}\}/g, '<code>$1</code>');

  // Linkler: [[label>>url:http://...]] veya [[http://...>>url:http://...]]
  html = html.replace(/\[\[([^\]]*?)>>url:(https?:\/\/[^\]]+)\]\]/g, (_, label, url) => {
    const displayLabel = label || url;
    return `<a href="${url}" target="_blank">${displayLabel}</a>`;
  });
  // Basit linkler: [[https://...]]
  html = html.replace(/\[\[(https?:\/\/[^\]]+)\]\]/g, '<a href="$1" target="_blank">$1</a>');

  // Görseller: [[image:filename.png]]
  html = html.replace(/\[\[image:([^\]]+)\]\]/g, '<img src="/api/attachments/$1" alt="$1" style="max-width:100%"/>');

  // Listeler — önce blokları grupla
  const lines = html.split('\n');
  const resultLines = [];
  let inUl = false, inOl = false;

  for (const line of lines) {
    const ulMatch = line.match(/^(\*+)\s+(.*)/);
    const olMatch = line.match(/^(1\.)\s+(.*)/);

    if (ulMatch) {
      if (!inUl) { resultLines.push('<ul>'); inUl = true; }
      if (inOl)  { resultLines.push('</ol>'); inOl = false; }
      resultLines.push(`<li>${ulMatch[2]}</li>`);
    } else if (olMatch) {
      if (!inOl) { resultLines.push('<ol>'); inOl = true; }
      if (inUl)  { resultLines.push('</ul>'); inUl = false; }
      resultLines.push(`<li>${olMatch[2]}</li>`);
    } else {
      if (inUl) { resultLines.push('</ul>'); inUl = false; }
      if (inOl) { resultLines.push('</ol>'); inOl = false; }
      resultLines.push(line);
    }
  }
  if (inUl) resultLines.push('</ul>');
  if (inOl) resultLines.push('</ol>');

  html = resultLines.join('\n');

  // Tablolar: |=Başlık|=Başlık2 ve |Hücre|Hücre2
  const tableLines = html.split('\n');
  const processedLines = [];
  let inTable = false;

  for (const line of tableLines) {
    if (line.trim().startsWith('|')) {
      if (!inTable) { processedLines.push('<table border="1" style="border-collapse:collapse;width:100%">'); inTable = true; }
      const isHeader = line.includes('|=');
      const cells = line.split('|').filter(c => c !== '');
      const tag = isHeader ? 'th' : 'td';
      const cellHtml = cells.map(c => `<${tag} style="padding:6px 10px">${c.replace(/^=/, '').trim()}</${tag}>`).join('');
      processedLines.push(`<tr>${cellHtml}</tr>`);
    } else {
      if (inTable) { processedLines.push('</table>'); inTable = false; }
      processedLines.push(line);
    }
  }
  if (inTable) processedLines.push('</table>');
  html = processedLines.join('\n');

  // Yatay çizgi: ----
  html = html.replace(/^----+\s*$/gm, '<hr/>');

  // Escape edilmiş karakterler: ~~ → ~, ~[ → [
  html = html.replace(/~~/g, '~');
  html = html.replace(/~\[/g, '[');
  html = html.replace(/~>/g, '>');

  // Boş başlıkları temizle
  html = html.replace(/<h[1-6]>\s*<\/h[1-6]>/g, '');

  // Paragraflar: art arda gelen boş satırları paragraf yap
  html = html
    .split(/\n{2,}/)
    .map(block => {
      block = block.trim();
      if (!block) return '';
      if (/^<(h[1-6]|ul|ol|li|pre|table|tr|hr|blockquote|img)/.test(block)) return block;
      return `<p>${block.replace(/\n/g, '<br/>')}</p>`;
    })
    .filter(Boolean)
    .join('\n');

  return html;
}

/**
 * XAR içindeki tek bir XML dosyasını parse et
 * Döndürür: { title, content (HTML), path, author, createdAt, updatedAt, attachments[] }
 */
function parseXmlDocument(xmlString) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlString, 'text/xml');

  const getText = (tag) => {
    const el = doc.getElementsByTagName(tag)[0];
    return el ? (el.textContent || '').trim() : '';
  };

  const title      = getText('title') || getText('n') || 'Başlıksız';
  const web        = getText('web');   // örn: Main.Uygulama_Grubu.Linux.OS.LVM
  const rawContent = getText('content');
  const author     = getText('author').replace('XWiki.', '');
  const creator    = getText('creator').replace('XWiki.', '');
  const createdAt  = new Date(parseInt(getText('creationDate'))).toISOString();
  const updatedAt  = new Date(parseInt(getText('date'))).toISOString();

  // Hiyerarşi path'ten grup çıkar
  // Örn: Main.Uygulama_Grubu.Linux.OS.LVM → breadcrumb: Linux > OS > LVM
  const pathParts = web.replace('Main.Uygulama_Grubu.', '').split('.');
  const breadcrumb = pathParts.join(' > ');

  // HTML'e çevir
  const contentHtml = xwikiToHtml(rawContent);

  // Attachment'ları topla
  const attachmentEls = doc.getElementsByTagName('attachment');
  const attachments = [];
  for (let i = 0; i < attachmentEls.length; i++) {
    const el = attachmentEls[i];
    const getChildText = (tag) => {
      const child = el.getElementsByTagName(tag)[0];
      return child ? child.textContent.trim() : '';
    };
    attachments.push({
      filename : getChildText('filename'),
      filesize : parseInt(getChildText('filesize') || '0'),
      mimetype : getChildText('mimetype'),
      content  : getChildText('content'), // base64
    });
  }

  return {
    title,
    web,
    breadcrumb,
    content: contentHtml,
    author,
    creator,
    created_at: createdAt,
    updated_at: updatedAt,
    attachments,
  };
}

module.exports = { parseXmlDocument, xwikiToHtml };
