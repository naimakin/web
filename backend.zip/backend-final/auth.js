// Grup yapılandırması ConfigMap'ten gelir (GROUP_CONFIG env)
// Format: JSON { "KEYCLOAK_GROUP_NAME": "Görünen Ad", ... }
function loadGroupConfig() {
  try {
    const raw = process.env.GROUP_CONFIG;
    if (!raw) {
      console.warn('GROUP_CONFIG env bulunamadı, varsayılan boş kullanılıyor.');
      return {};
    }
    return JSON.parse(raw);
  } catch(e) {
    console.error('GROUP_CONFIG parse hatası:', e.message);
    return {};
  }
}

const ADMIN_GROUP    = process.env.ADMIN_GROUP    || 'BTAOM_YONETICILER';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;

const GROUP_CONFIG = loadGroupConfig();
const KNOWN_GROUPS = Object.keys(GROUP_CONFIG);

console.log(`Yüklenen gruplar (${KNOWN_GROUPS.length}):`, KNOWN_GROUPS.join(', '));
console.log(`Admin grubu: ${ADMIN_GROUP}`);

function parseUser(req) {
  const email  = req.headers['x-user-email']  || '';
  const name   = req.headers['x-user-name']   || '';
  let allGroups = [];
  try { allGroups = JSON.parse(req.headers['x-user-groups'] || '[]'); } catch(_) {}
  const groups  = allGroups.filter(g => KNOWN_GROUPS.includes(g));
  const isAdmin = groups.includes(ADMIN_GROUP);
  return { email, name, groups, isAdmin };
}

function requireAuth(req, res, next) {
  const authHeader = req.headers['authorization'] || '';
  if (authHeader.startsWith('Basic ')) {
    const decoded = Buffer.from(authHeader.slice(6), 'base64').toString();
    const [user, pass] = decoded.split(':');
    if (ADMIN_USERNAME && ADMIN_PASSWORD && user === ADMIN_USERNAME && pass === ADMIN_PASSWORD) {
      req.user = { email: ADMIN_USERNAME, name: 'Süper Admin', groups: KNOWN_GROUPS, isAdmin: true, isSuperAdmin: true };
      return next();
    }
  }
  const user = parseUser(req);
  if (!user.email)                              return res.status(401).json({ error: 'Yetkisiz erişim' });
  if (user.groups.length === 0 && !user.isAdmin) return res.status(403).json({ error: 'Hiçbir gruba üye değilsiniz' });
  req.user = user;
  next();
}

function canRead(user, note) {
  if (user.isSuperAdmin || user.isAdmin)                                              return true;
  if (user.groups.includes(note.owner_group))                                        return true;
  if (note.shared_to && user.groups.includes(note.shared_to))                       return true;
  return false;
}

function canWrite(user, note) {
  if (user.isSuperAdmin || user.isAdmin)                                              return true;
  if (user.groups.includes(note.owner_group))                                        return true;
  if (note.shared_to && user.groups.includes(note.shared_to) && note.share_permission === 'write') return true;
  return false;
}

function canDelete(user, note) {
  if (user.isSuperAdmin || user.isAdmin) return true;
  return user.groups.includes(note.owner_group);
}

module.exports = { requireAuth, canRead, canWrite, canDelete, KNOWN_GROUPS, ADMIN_GROUP, GROUP_CONFIG };
