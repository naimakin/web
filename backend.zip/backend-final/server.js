require('dotenv').config();
const express = require('express');
const { pool, initDB } = require('./db');
const { requireAuth, canRead, canWrite, canDelete, KNOWN_GROUPS } = require('./auth');
const importExportRouter = require('./import-export');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(express.json({ limit: '10mb' }));

// Sağlık kontrolü (K8s liveness/readiness probe)
app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', db: 'ok' });
  } catch(e) {
    res.status(503).json({ status: 'error', db: e.message });
  }
});

// ── NOTES ─────────────────────────────────────────────────

// GET /api/notes — not listesi
// ?filter=mine    → kendi grubumun notları
// ?filter=shared  → benimle paylaşılan notlar
// ?group=BT-NETWORK → admin: belirli grubun notları (sadece admin)
// ?q=arama        → başlık arama
app.get('/api/notes', requireAuth, async (req, res) => {
  const { filter, group, q } = req.query;
  const user = req.user;

  try {
    let query, params;

    if (group && (user.isAdmin || user.isSuperAdmin)) {
      // Admin: belirli grup
      query = `SELECT id, title, owner_group, created_by, shared_to, share_permission, created_at, updated_at
               FROM notes WHERE owner_group = $1`;
      params = [group];
    } else if (filter === 'shared') {
      // Benimle paylaşılan notlar (başka grubun notu ama benim grubuma paylaşılmış)
      const placeholders = user.groups.map((_, i) => `$${i + 1}`).join(',');
      if (user.groups.length === 0) return res.json([]);
      query = `SELECT id, title, owner_group, created_by, shared_to, share_permission, created_at, updated_at
               FROM notes
               WHERE shared_to = ANY($1::text[])
               AND NOT (owner_group = ANY($1::text[]))`;
      params = [user.groups];
    } else {
      // Varsayılan: kendi grubumun notları
      if (user.groups.length === 0 && !user.isSuperAdmin) return res.json([]);
      const groups = user.isSuperAdmin ? KNOWN_GROUPS : user.groups;
      query = `SELECT id, title, owner_group, created_by, shared_to, share_permission, created_at, updated_at
               FROM notes WHERE owner_group = ANY($1::text[])`;
      params = [groups];
    }

    // Arama filtresi
    if (q) {
      query += ` AND title ILIKE $${params.length + 1}`;
      params.push(`%${q}%`);
    }

    query += ` ORDER BY updated_at DESC`;

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch(e) {
    console.error('GET /api/notes hatası:', e.message);
    res.status(500).json({ error: 'Notlar alınamadı' });
  }
});

// GET /api/notes/:id — tek not (içerik dahil)
app.get('/api/notes/:id', requireAuth, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = result.rows[0];
    if (!canRead(req.user, note)) return res.status(403).json({ error: 'Erişim yetkisi yok' });
    res.json(note);
  } catch(e) {
    console.error('GET /api/notes/:id hatası:', e.message);
    res.status(500).json({ error: 'Not alınamadı' });
  }
});

// POST /api/notes — yeni not oluştur
app.post('/api/notes', requireAuth, async (req, res) => {
  const { title, content, group } = req.body;
  const user = req.user;

  // Grup seçimi: isteğin grubu, yoksa kullanıcının ilk grubu
  const ownerGroup = group || user.groups[0];
  if (!ownerGroup) return res.status(400).json({ error: 'Grup belirtilmedi' });

  // Kendi grubuna veya admin başka gruba not açabilir
  if (!user.isAdmin && !user.isSuperAdmin && !user.groups.includes(ownerGroup)) {
    return res.status(403).json({ error: 'Bu gruba not ekleyemezsiniz' });
  }

  try {
    const result = await pool.query(
      `INSERT INTO notes (title, content, owner_group, created_by)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [title || 'Yeni Not', content || '', ownerGroup, user.email]
    );
    res.status(201).json(result.rows[0]);
  } catch(e) {
    console.error('POST /api/notes hatası:', e.message);
    res.status(500).json({ error: 'Not oluşturulamadı' });
  }
});

// PUT /api/notes/:id — notu güncelle
app.put('/api/notes/:id', requireAuth, async (req, res) => {
  const { title, content } = req.body;
  try {
    const existing = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = existing.rows[0];
    if (!canWrite(req.user, note)) return res.status(403).json({ error: 'Düzenleme yetkisi yok' });

    const result = await pool.query(
      `UPDATE notes SET title = $1, content = $2 WHERE id = $3 RETURNING *`,
      [title ?? note.title, content ?? note.content, req.params.id]
    );
    res.json(result.rows[0]);
  } catch(e) {
    console.error('PUT /api/notes/:id hatası:', e.message);
    res.status(500).json({ error: 'Not güncellenemedi' });
  }
});

// DELETE /api/notes/:id — notu sil
app.delete('/api/notes/:id', requireAuth, async (req, res) => {
  try {
    const existing = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = existing.rows[0];
    if (!canDelete(req.user, note)) return res.status(403).json({ error: 'Silme yetkisi yok' });

    await pool.query('DELETE FROM notes WHERE id = $1', [req.params.id]);
    res.json({ ok: true });
  } catch(e) {
    console.error('DELETE /api/notes/:id hatası:', e.message);
    res.status(500).json({ error: 'Not silinemedi' });
  }
});

// POST /api/notes/:id/share — notu paylaş
app.post('/api/notes/:id/share', requireAuth, async (req, res) => {
  const { shared_to, permission } = req.body;
  if (!shared_to) return res.status(400).json({ error: 'Hedef grup belirtilmedi' });
  if (!['read','write'].includes(permission)) return res.status(400).json({ error: 'Geçersiz yetki (read|write)' });

  try {
    const existing = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = existing.rows[0];

    // Sadece sahibi veya admin paylaşabilir
    if (!req.user.groups.includes(note.owner_group) && !req.user.isAdmin && !req.user.isSuperAdmin) {
      return res.status(403).json({ error: 'Paylaşım yetkisi yok' });
    }
    // Kendi grubuna paylaşamazsın
    if (shared_to === note.owner_group) {
      return res.status(400).json({ error: 'Notun sahibi gruba paylaşım yapılamaz' });
    }

    const result = await pool.query(
      `UPDATE notes SET shared_to = $1, share_permission = $2 WHERE id = $3 RETURNING *`,
      [shared_to, permission, req.params.id]
    );
    res.json(result.rows[0]);
  } catch(e) {
    console.error('POST /api/notes/:id/share hatası:', e.message);
    res.status(500).json({ error: 'Paylaşım yapılamadı' });
  }
});

// DELETE /api/notes/:id/share — paylaşımı kaldır
app.delete('/api/notes/:id/share', requireAuth, async (req, res) => {
  try {
    const existing = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = existing.rows[0];
    if (!req.user.groups.includes(note.owner_group) && !req.user.isAdmin && !req.user.isSuperAdmin) {
      return res.status(403).json({ error: 'Yetki yok' });
    }
    const result = await pool.query(
      `UPDATE notes SET shared_to = NULL, share_permission = NULL WHERE id = $1 RETURNING *`,
      [req.params.id]
    );
    res.json(result.rows[0]);
  } catch(e) {
    res.status(500).json({ error: 'Paylaşım kaldırılamadı' });
  }
});

// ── ADMIN ─────────────────────────────────────────────────

// GET /api/admin/stats — grup bazlı istatistik
app.get('/api/admin/stats', requireAuth, async (req, res) => {
  if (!req.user.isAdmin && !req.user.isSuperAdmin) {
    return res.status(403).json({ error: 'Admin yetkisi gerekli' });
  }
  try {
    const result = await pool.query(`
      SELECT owner_group, COUNT(*) as note_count,
             MAX(updated_at) as last_updated
      FROM notes
      GROUP BY owner_group
      ORDER BY note_count DESC
    `);
    res.json(result.rows);
  } catch(e) {
    res.status(500).json({ error: 'İstatistikler alınamadı' });
  }
});

// ── IMPORT / EXPORT ────────────────────────────────────────
app.use('/api/import', importExportRouter);
app.use('/api/export', importExportRouter);

// ── START ──────────────────────────────────────────────────
initDB()
  .then(() => {
    app.listen(PORT, () => console.log(`Backend çalışıyor: http://localhost:${PORT}`));
  })
  .catch(err => {
    console.error('Veritabanı başlatılamadı:', err.message);
    process.exit(1);
  });
