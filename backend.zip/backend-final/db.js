const { Pool } = require('pg');

const pool = new Pool({
  host:     process.env.POSTGRES_HOST     || 'postgres-public',
  port:     parseInt(process.env.POSTGRES_PORT || '5432'),
  database: process.env.POSTGRES_DB,
  user:     process.env.POSTGRES_USER,
  password: process.env.POSTGRES_PASSWORD,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
  console.error('PostgreSQL bağlantı hatası:', err.message);
});

// Tabloları oluştur (uygulama ilk açıldığında)
async function initDB() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS notes (
        id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        title        TEXT NOT NULL DEFAULT 'Başlıksız Not',
        content      TEXT NOT NULL DEFAULT '',
        owner_group  TEXT NOT NULL,
        created_by   TEXT NOT NULL,
        shared_to    TEXT,
        share_permission TEXT CHECK (share_permission IN ('read','write')),
        created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `);

    // updated_at otomatik güncellemek için trigger
    await client.query(`
      CREATE OR REPLACE FUNCTION update_updated_at()
      RETURNS TRIGGER AS $$
      BEGIN
        NEW.updated_at = NOW();
        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql;
    `);

    await client.query(`
      DROP TRIGGER IF EXISTS notes_updated_at ON notes;
      CREATE TRIGGER notes_updated_at
        BEFORE UPDATE ON notes
        FOR EACH ROW EXECUTE FUNCTION update_updated_at();
    `);

    console.log('Veritabanı hazır.');
  } finally {
    client.release();
  }
}

module.exports = { pool, initDB };
