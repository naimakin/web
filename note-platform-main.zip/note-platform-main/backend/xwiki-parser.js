const { DOMParser } = require('@xmldom/xmldom');

function xwikiToHtml(text) {
  if (!text) return '';
  let html = text;

  html = html.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

  // Kod blokları
  html = html.replace(/\{\{code[^}]*\}\}([\s\S]*?)\{\{\/code\}\}/g, (_, code) => {
    const escaped = code.trim().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    return `<pre><code>${escaped}</code></pre>`;
  });

  // Velocity/Groovy makrolar
  html = html.replace(/\{\{velocity\}\}[\s\S]*?\{\{\/velocity\}\}/gi, '');
  html = html.replace(/\{\{groovy\}\}[\s\S]*?\{\{\/groovy\}\}/gi, '');

  // info/warning/error kutuları
  html = html.replace(/\{\{info\}\}([\s\S]*?)\{\{\/info\}\}/g, '<div style="background:rgba(79,142,247,0.1);border-left:3px solid #4f8ef7;padding:10px 14px;margin:8px 0;border-radius:4px">ℹ️ $1</div>');
  html = html.replace(/\{\{warning\}\}([\s\S]*?)\{\{\/warning\}\}/g, '<div style="background:rgba(224,160,80,0.1);border-left:3px solid #e0a050;padding:10px 14px;margin:8px 0;border-radius:4px">⚠️ $1</div>');
  html = html.replace(/\{\{error\}\}([\s\S]*?)\{\{\/error\}\}/g, '<div style="background:rgba(224,82,82,0.1);border-left:3px solid #e05252;padding:10px 14px;margin:8px 0;border-radius:4px">❌ $1</div>');

  // Diğer makrolar — içeriği koru
  html = html.replace(/\{\{[^}]+\}\}([\s\S]*?)\{\{\/[^}]+\}\}/g, '$1');
  html = html.replace(/\{\{[^}]+\}\}/g, '');

  // Stil blokları
  html = html.replace(/\(%\s*class="mark"\s*%\)(.*?)(?=\n|$)/g, '<mark>$1</mark>');
  html = html.replace(/\(%[^%]*%\)/g, '');
  html = html.replace(/%%/g, '');

  // Başlıklar (uzundan kısaya işle)
  html = html.replace(/^======\s*(.*?)\s*======\s*$/gm, '<h6>$1</h6>');
  html = html.replace(/^=====\s*(.*?)\s*=====\s*$/gm,  '<h5>$1</h5>');
  html = html.replace(/^====\s*(.*?)\s*====\s*$/gm,    '<h4>$1</h4>');
  html = html.replace(/^===\s*(.*?)\s*===\s*$/gm,      '<h3>$1</h3>');
  html = html.replace(/^==\s*(.*?)\s*==\s*$/gm,        '<h2>$1</h2>');
  html = html.replace(/^=\s*(.*?)\s*=\s*$/gm,          '<h1>$1</h1>');

  // Inline formatlar
  html = html.replace(/\*\*__(.*?)__\*\*/g, '<strong><em>$1</em></strong>');
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\/\/(.*?)\/\//g, '<em>$1</em>');
  html = html.replace(/__(.*?)__/g, '<u>$1</u>');
  html = html.replace(/~~(.*?)~~/g, '<s>$1</s>');
  html = html.replace(/##(.*?)##/g, '<code>$1</code>');
  html = html.replace(/\{\{\{\{(.*?)\}\}\}\}/g, '<code>$1</code>');

  // Linkler
  html = html.replace(/\[\[([^\]]*?)>>url:(https?:\/\/[^\]]+)\]\]/g, (_, label, url) =>
    `<a href="${url}" target="_blank">${label || url}</a>`
  );
  html = html.replace(/\[\[(https?:\/\/[^\]]+)\]\]/g, '<a href="$1" target="_blank">$1</a>');

  // Görseller
  html = html.replace(/\[\[image:([^\]]+)\]\]/g,
    '<img src="/api/attachments/$1" alt="$1" style="max-width:100%;border-radius:4px;margin:4px 0"/>'
  );

  // Listeler
  const lines = html.split('\n');
  const out = [];
  let inUl = false, inOl = false;
  for (const line of lines) {
    const ul = line.match(/^(\*+)\s+(.*)/);
    const ol = line.match(/^(1\.)\s+(.*)/);
    if (ul) {
      if (!inUl) { out.push('<ul>'); inUl = true; }
      if (inOl)  { out.push('</ol>'); inOl = false; }
      const indent = (ul[1].length - 1) * 20;
      out.push(`<li style="margin-left:${indent}px">${ul[2]}</li>`);
    } else if (ol) {
      if (!inOl) { out.push('<ol>'); inOl = true; }
      if (inUl)  { out.push('</ul>'); inUl = false; }
      out.push(`<li>${ol[2]}</li>`);
    } else {
      if (inUl) { out.push('</ul>'); inUl = false; }
      if (inOl) { out.push('</ol>'); inOl = false; }
      out.push(line);
    }
  }
  if (inUl) out.push('</ul>');
  if (inOl) out.push('</ol>');
  html = out.join('\n');

  // Tablolar
  const tlines = html.split('\n');
  const tout = [];
  let inTable = false;
  for (const line of tlines) {
    if (line.trim().startsWith('|')) {
      if (!inTable) { tout.push('<table style="border-collapse:collapse;width:100%;margin:8px 0">'); inTable = true; }
      const isHeader = line.includes('|=');
      const cells = line.split('|').filter(c => c !== '');
      const tag = isHeader ? 'th' : 'td';
      const style = isHeader
        ? 'padding:8px 12px;background:rgba(79,142,247,0.15);font-weight:600;border:1px solid rgba(255,255,255,0.1)'
        : 'padding:8px 12px;border:1px solid rgba(255,255,255,0.1)';
      tout.push(`<tr>${cells.map(c => `<${tag} style="${style}">${c.replace(/^=/, '').trim()}</${tag}>`).join('')}</tr>`);
    } else {
      if (inTable) { tout.push('</table>'); inTable = false; }
      tout.push(line);
    }
  }
  if (inTable) tout.push('</table>');
  html = tout.join('\n');

  html = html.replace(/^----+\s*$/gm, '<hr style="border:none;border-top:1px solid rgba(255,255,255,0.1);margin:16px 0"/>');
  html = html.replace(/<h[1-6]>\s*<\/h[1-6]>/g, '');

  // Paragraflar
  html = html
    .split(/\n{2,}/)
    .map(block => {
      block = block.trim();
      if (!block) return '';
      if (/^<(h[1-6]|ul|ol|li|pre|table|tr|hr|div|blockquote|img)/.test(block)) return block;
      return `<p style="margin:0 0 0.8em">${block.replace(/\n/g, '<br/>')}</p>`;
    })
    .filter(Boolean)
    .join('\n');

  return html;
}

function parseXmlDocument(xmlString) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlString, 'text/xml');

  const getText = (tag) => {
    const el = doc.getElementsByTagName(tag)[0];
    if (!el) return '';
    // CDATA veya textContent
    let text = '';
    for (let i = 0; i < el.childNodes.length; i++) {
      const node = el.childNodes[i];
      text += node.nodeValue || node.textContent || '';
    }
    return text.trim();
  };

  const title     = getText('title') || getText('name') || 'Başlıksız';
  const web       = getText('web');
  const rawContent= getText('content');
  const author    = (getText('author') || getText('creator') || '').replace('XWiki.', '');

  let createdAt = new Date().toISOString();
  let updatedAt = new Date().toISOString();
  try {
    const cd = parseInt(getText('creationDate'));
    const ud = parseInt(getText('date'));
    if (cd && !isNaN(cd)) createdAt = new Date(cd).toISOString();
    if (ud && !isNaN(ud)) updatedAt = new Date(ud).toISOString();
  } catch(_) {}

  const pathParts = web.replace(/^Main\.Uygulama_Grubu\./, '').split('.').filter(Boolean);
  const breadcrumb = pathParts.join(' › ');

  const contentHtml = xwikiToHtml(rawContent);

  // Attachment'lar
  const attachmentEls = doc.getElementsByTagName('attachment');
  const attachments = [];
  for (let i = 0; i < attachmentEls.length; i++) {
    const el = attachmentEls[i];
    const getChild = (tag) => {
      const c = el.getElementsByTagName(tag)[0];
      return c ? (c.textContent || '').trim() : '';
    };
    attachments.push({
      filename: getChild('filename'),
      filesize: parseInt(getChild('filesize') || '0'),
      mimetype: getChild('mimetype'),
      content:  getChild('content'),
    });
  }

  return { title, web, breadcrumb, content: contentHtml, author, created_at: createdAt, updated_at: updatedAt, attachments };
}

module.exports = { parseXmlDocument, xwikiToHtml };
