require('dotenv').config();
const express = require('express');
const { pool, initDB } = require('./db');
const { requireAuth, canRead, canWrite, canDelete, KNOWN_GROUPS } = require('./auth');
const importExportRouter = require('./import-export');

const app  = express();
const PORT = process.env.PORT || 4000;

app.use(express.json({ limit: '50mb' }));

// ── HEALTH ──────────────────────────────────────────────────
app.get('/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ status: 'ok', db: 'ok' }); }
  catch(e) { res.status(503).json({ status: 'error', db: e.message }); }
});

// ── NOTES LIST ───────────────────────────────────────────────
// filter=personal  → sadece bu kullanıcının kişisel notları (owner_group IS NULL)
// filter=group     → kullanıcının gruplarına ait notlar
// filter=shared    → kullanıcıya paylaşılan notlar
// group=X          → admin: belirli grubun notları
app.get('/api/notes', requireAuth, async (req, res) => {
  const { filter = 'personal', group, q } = req.query;
  const user = req.user;
  try {
    let query, params;

    if (group && (user.isAdmin || user.isSuperAdmin)) {
      // Admin: belirli grubun tüm notları
      query  = `SELECT id, title, owner_group, created_by, parent_id, shared_to, share_permission, created_at, updated_at
                FROM notes WHERE owner_group = $1`;
      params = [group];

    } else if (filter === 'personal') {
      // Kişisel notlar: bu kullanıcıya ait, gruba paylaşılmamış
      query  = `SELECT id, title, owner_group, created_by, parent_id, shared_to, share_permission, created_at, updated_at
                FROM notes WHERE created_by = $1 AND owner_group IS NULL`;
      params = [user.email];

    } else if (filter === 'group') {
      // Gruba paylaşılmış notlar (kullanıcının grupları)
      if (user.groups.length === 0 && !user.isSuperAdmin) return res.json([]);
      const groups = user.isSuperAdmin ? KNOWN_GROUPS : user.groups;
      query  = `SELECT id, title, owner_group, created_by, parent_id, shared_to, share_permission, created_at, updated_at
                FROM notes WHERE owner_group = ANY($1::text[])`;
      params = [groups];

    } else if (filter === 'shared') {
      // Başka gruptan paylaşılan notlar
      if (user.groups.length === 0) return res.json([]);
      query  = `SELECT id, title, owner_group, created_by, parent_id, shared_to, share_permission, created_at, updated_at
                FROM notes
                WHERE shared_to = ANY($1::text[])
                AND (owner_group IS NULL OR NOT (owner_group = ANY($1::text[])))`;
      params = [user.groups];

    } else {
      return res.json([]);
    }

    if (q) { query += ` AND title ILIKE $${params.length + 1}`; params.push(`%${q}%`); }
    query += ` ORDER BY updated_at DESC`;

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch(e) {
    console.error('GET /api/notes hatası:', e.message);
    res.status(500).json({ error: 'Notlar alınamadı' });
  }
});

// ── SINGLE NOTE ──────────────────────────────────────────────
app.get('/api/notes/:id', requireAuth, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = result.rows[0];
    if (!canRead(req.user, note)) return res.status(403).json({ error: 'Erişim yetkisi yok' });
    res.json(note);
  } catch(e) { res.status(500).json({ error: 'Not alınamadı' }); }
});

// ── CREATE NOTE ──────────────────────────────────────────────
app.post('/api/notes', requireAuth, async (req, res) => {
  const { title, content, parent_id } = req.body;
  // owner_group her zaman NULL başlar (kişisel)
  try {
    let validParent = parent_id || null;
    if (validParent) {
      const pr = await pool.query('SELECT created_by FROM notes WHERE id = $1', [validParent]);
      if (pr.rows.length === 0 || pr.rows[0].created_by !== req.user.email) validParent = null;
    }
    const result = await pool.query(
      `INSERT INTO notes (title, content, created_by, owner_group, parent_id)
       VALUES ($1, $2, $3, NULL, $4) RETURNING *`,
      [title || 'Yeni Not', content || '', req.user.email, validParent]
    );
    res.status(201).json(result.rows[0]);
  } catch(e) {
    console.error('POST /api/notes hatası:', e.message);
    res.status(500).json({ error: 'Not oluşturulamadı' });
  }
});

// ── UPDATE NOTE ──────────────────────────────────────────────
app.put('/api/notes/:id', requireAuth, async (req, res) => {
  const { title, content, parent_id } = req.body;
  try {
    const existing = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = existing.rows[0];
    if (!canWrite(req.user, note)) return res.status(403).json({ error: 'Düzenleme yetkisi yok' });

    let newParent = note.parent_id;
    if (parent_id !== undefined) {
      newParent = parent_id || null;
      if (newParent === req.params.id) newParent = null;
    }

    const result = await pool.query(
      `UPDATE notes SET title=$1, content=$2, parent_id=$3 WHERE id=$4 RETURNING *`,
      [title ?? note.title, content ?? note.content, newParent, req.params.id]
    );
    res.json(result.rows[0]);
  } catch(e) {
    console.error('PUT hatası:', e.message);
    res.status(500).json({ error: 'Not güncellenemedi' });
  }
});

// ── DELETE NOTE ──────────────────────────────────────────────
app.delete('/api/notes/:id', requireAuth, async (req, res) => {
  try {
    const existing = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = existing.rows[0];
    if (!canDelete(req.user, note)) return res.status(403).json({ error: 'Silme yetkisi yok' });
    await pool.query('UPDATE notes SET parent_id=$1 WHERE parent_id=$2', [note.parent_id, req.params.id]);
    await pool.query('DELETE FROM notes WHERE id=$1', [req.params.id]);
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: 'Not silinemedi' }); }
});

// ── PUBLISH TO GROUP (kişisel → gruba paylaş) ────────────────
app.post('/api/notes/:id/publish', requireAuth, async (req, res) => {
  const { group } = req.body;
  if (!group) return res.status(400).json({ error: 'Grup belirtilmedi' });

  try {
    const existing = await pool.query('SELECT * FROM notes WHERE id=$1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = existing.rows[0];

    // Sadece notun sahibi yayınlayabilir
    if (note.created_by !== req.user.email && !req.user.isSuperAdmin)
      return res.status(403).json({ error: 'Sadece not sahibi yayınlayabilir' });

    // Kullanıcı o grubun üyesi mi?
    if (!req.user.groups.includes(group) && !req.user.isAdmin && !req.user.isSuperAdmin)
      return res.status(403).json({ error: 'Bu grubun üyesi değilsiniz' });

    const result = await pool.query(
      `UPDATE notes SET owner_group=$1 WHERE id=$2 RETURNING *`,
      [group, req.params.id]
    );
    res.json(result.rows[0]);
  } catch(e) {
    console.error('Publish hatası:', e.message);
    res.status(500).json({ error: 'Gruba yayınlanamadı' });
  }
});

// ── UNPUBLISH (gruptan geri al → kişisel yap) ────────────────
app.post('/api/notes/:id/unpublish', requireAuth, async (req, res) => {
  try {
    const existing = await pool.query('SELECT * FROM notes WHERE id=$1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = existing.rows[0];
    if (note.created_by !== req.user.email && !req.user.isSuperAdmin)
      return res.status(403).json({ error: 'Sadece not sahibi geri alabilir' });
    const result = await pool.query(
      `UPDATE notes SET owner_group=NULL, shared_to=NULL, share_permission=NULL WHERE id=$1 RETURNING *`,
      [req.params.id]
    );
    res.json(result.rows[0]);
  } catch(e) { res.status(500).json({ error: 'Geri alınamadı' }); }
});

// ── SHARE (grup notunu başka grupla paylaş) ──────────────────
app.post('/api/notes/:id/share', requireAuth, async (req, res) => {
  const { shared_to, permission } = req.body;
  if (!shared_to) return res.status(400).json({ error: 'Hedef grup belirtilmedi' });
  if (!['read','write'].includes(permission)) return res.status(400).json({ error: 'Geçersiz yetki' });
  try {
    const existing = await pool.query('SELECT * FROM notes WHERE id=$1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = existing.rows[0];
    if (!note.owner_group) return res.status(400).json({ error: 'Önce gruba yayınlayın' });
    if (!req.user.groups.includes(note.owner_group) && !req.user.isAdmin && !req.user.isSuperAdmin)
      return res.status(403).json({ error: 'Paylaşım yetkisi yok' });
    if (shared_to === note.owner_group)
      return res.status(400).json({ error: 'Aynı gruba paylaşım yapılamaz' });
    const result = await pool.query(
      `UPDATE notes SET shared_to=$1, share_permission=$2 WHERE id=$3 RETURNING *`,
      [shared_to, permission, req.params.id]
    );
    res.json(result.rows[0]);
  } catch(e) { res.status(500).json({ error: 'Paylaşım yapılamadı' }); }
});

app.delete('/api/notes/:id/share', requireAuth, async (req, res) => {
  try {
    const existing = await pool.query('SELECT * FROM notes WHERE id=$1', [req.params.id]);
    if (existing.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = existing.rows[0];
    if (note.created_by !== req.user.email && !req.user.isAdmin && !req.user.isSuperAdmin)
      return res.status(403).json({ error: 'Yetki yok' });
    const result = await pool.query(
      `UPDATE notes SET shared_to=NULL, share_permission=NULL WHERE id=$1 RETURNING *`,
      [req.params.id]
    );
    res.json(result.rows[0]);
  } catch(e) { res.status(500).json({ error: 'Paylaşım kaldırılamadı' }); }
});

// ── ADMIN STATS ──────────────────────────────────────────────
app.get('/api/admin/stats', requireAuth, async (req, res) => {
  if (!req.user.isAdmin && !req.user.isSuperAdmin)
    return res.status(403).json({ error: 'Admin yetkisi gerekli' });
  try {
    const result = await pool.query(`
      SELECT owner_group, COUNT(*) as note_count, MAX(updated_at) as last_updated
      FROM notes WHERE owner_group IS NOT NULL
      GROUP BY owner_group ORDER BY note_count DESC
    `);
    res.json(result.rows);
  } catch(e) { res.status(500).json({ error: 'İstatistikler alınamadı' }); }
});

// ── IMPORT / EXPORT ──────────────────────────────────────────
app.use('/api/import', importExportRouter);
app.use('/api/export', importExportRouter);

// ── START ────────────────────────────────────────────────────
initDB()
  .then(() => app.listen(PORT, () => console.log(`Backend çalışıyor: http://localhost:${PORT}`)))
  .catch(err => { console.error('DB başlatılamadı:', err.message); process.exit(1); });
