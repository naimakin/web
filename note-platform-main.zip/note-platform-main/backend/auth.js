function loadGroupConfig() {
  try {
    const raw = process.env.GROUP_CONFIG;
    if (!raw) { console.warn('GROUP_CONFIG bulunamadı.'); return {}; }
    return JSON.parse(raw);
  } catch(e) { console.error('GROUP_CONFIG parse hatası:', e.message); return {}; }
}

const ADMIN_GROUP    = process.env.ADMIN_GROUP    || 'BTAOM_YONETICILER';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const GROUP_CONFIG   = loadGroupConfig();
const KNOWN_GROUPS   = Object.keys(GROUP_CONFIG);

console.log(`Gruplar (${KNOWN_GROUPS.length}):`, KNOWN_GROUPS.join(', '));

function decodeHeader(val) {
  if (!val) return '';
  try { return Buffer.from(val, 'base64').toString('utf8'); } catch(_) { return val; }
}

function parseUser(req) {
  const isBase64    = req.headers['x-user-encoding'] === 'base64';
  const isSuperAdmin= req.headers['x-super-admin'] === '1';
  const email       = (isBase64 ? decodeHeader(req.headers['x-user-email']) : (req.headers['x-user-email'] || '')).trim().toLowerCase();
  const name        = isBase64 ? decodeHeader(req.headers['x-user-name'])  : (req.headers['x-user-name']  || '');

  let allGroups = [];
  try {
    const raw = isBase64 ? decodeHeader(req.headers['x-user-groups']) : (req.headers['x-user-groups'] || '[]');
    allGroups = JSON.parse(raw);
  } catch(_) {}

  if (isSuperAdmin) return { email, name, groups: KNOWN_GROUPS, isAdmin: true, isSuperAdmin: true };

  const groups  = allGroups.filter(g => KNOWN_GROUPS.includes(g));
  const isAdmin = groups.includes(ADMIN_GROUP);
  return { email, name, groups, isAdmin, isSuperAdmin: false };
}

function requireAuth(req, res, next) {
  // Basic auth (süper admin / curl)
  const auth = req.headers['authorization'] || '';
  if (auth.startsWith('Basic ')) {
    const decoded = Buffer.from(auth.slice(6), 'base64').toString();
    const [user, pass] = decoded.split(':');
    if (ADMIN_USERNAME && ADMIN_PASSWORD && user === ADMIN_USERNAME && pass === ADMIN_PASSWORD) {
      req.user = { email: ADMIN_USERNAME, name: 'Süper Admin', groups: KNOWN_GROUPS, isAdmin: true, isSuperAdmin: true };
      return next();
    }
  }
  const user = parseUser(req);
  if (!user.email) return res.status(401).json({ error: 'Yetkisiz erişim' });
  req.user = user;
  next();
}

// Okuma: not sahibi VEYA gruba paylaşılmış VEYA admin
function canRead(user, note) {
  if (user.isSuperAdmin || user.isAdmin)                                                     return true;
  if (note.created_by === user.email)                                                        return true;  // kişisel notu
  if (note.owner_group && user.groups.includes(note.owner_group))                           return true;  // grup notu
  if (note.shared_to && user.groups.includes(note.shared_to))                               return true;  // paylaşılan
  return false;
}

// Yazma: not sahibi VEYA write izniyle paylaşılmış VEYA admin
function canWrite(user, note) {
  if (user.isSuperAdmin || user.isAdmin)                                                     return true;
  if (note.created_by === user.email)                                                        return true;
  if (note.owner_group && user.groups.includes(note.owner_group))                           return true;
  if (note.shared_to && user.groups.includes(note.shared_to) && note.share_permission === 'write') return true;
  return false;
}

// Silme: not sahibi VEYA admin
function canDelete(user, note) {
  if (user.isSuperAdmin || user.isAdmin)   return true;
  return note.created_by === user.email;
}

module.exports = { requireAuth, canRead, canWrite, canDelete, KNOWN_GROUPS, ADMIN_GROUP, GROUP_CONFIG };
