const express  = require('express');
const router   = express.Router();
const AdmZip   = require('adm-zip');
const { pool } = require('./db');
const { requireAuth, canRead, KNOWN_GROUPS } = require('./auth');
const { parseXmlDocument } = require('./xwiki-parser');

// ── IMPORT: XAR ─────────────────────────────────────────────
router.post('/xar', requireAuth, async (req, res) => {
  if (!req.user.isAdmin && !req.user.isSuperAdmin && req.user.groups.length === 0)
    return res.status(403).json({ error: 'Import yetkisi yok' });

  const chunks = [];
  req.on('data', chunk => chunks.push(chunk));
  req.on('end', async () => {
    try {
      const body     = Buffer.concat(chunks);
      const boundary = req.headers['content-type'].split('boundary=')[1];
      const parts    = parseMultipart(body, boundary);

      const filePart    = parts.find(p => p.name === 'file');
      const groupPart   = parts.find(p => p.name === 'target_group');
      const prefixPart  = parts.find(p => p.name === 'title_prefix');

      if (!filePart) return res.status(400).json({ error: 'XAR dosyası bulunamadı' });

      const targetGroup = groupPart ? groupPart.data.toString().trim() : (req.user.groups[0] || KNOWN_GROUPS[0]);
      if (!req.user.isAdmin && !req.user.isSuperAdmin && !req.user.groups.includes(targetGroup))
        return res.status(403).json({ error: 'Bu gruba import yetkisi yok' });

      const titlePrefix = prefixPart ? prefixPart.data.toString().trim() : '';

      const zip = new AdmZip(filePart.data);
      const entries = zip.getEntries()
        .filter(e => !e.isDirectory && e.entryName.endsWith('.xml') && e.entryName !== 'package.xml');

      const results = { imported: 0, skipped: 0, errors: [] };

      // İlk geçiş: tüm sayfaları parse et ve path → id eşlemesi oluştur (hiyerarşi için)
      const parsedPages = [];
      for (const entry of entries) {
        try {
          const xmlStr = entry.getData().toString('utf8');
          const parsed = parseXmlDocument(xmlStr);
          parsedPages.push({ ...parsed, entryName: entry.entryName });
        } catch(e) {
          results.errors.push({ file: entry.entryName, error: e.message });
          results.skipped++;
        }
      }

      // İkinci geçiş: path derinliğine göre sırala (üst sayfalar önce oluşturulsun)
      parsedPages.sort((a, b) => {
        const da = (a.web || '').split('.').length;
        const db = (b.web || '').split('.').length;
        return da - db;
      });

      // web path → DB id eşlemesi
      const pathToId = {};

      for (const page of parsedPages) {
        try {
          const noteTitle = titlePrefix ? `${titlePrefix}${page.title}` : page.title;

          // Üst not path'ini bul
          let parentDbId = null;
          if (page.web) {
            const parts = page.web.split('.');
            if (parts.length > 1) {
              const parentPath = parts.slice(0, -1).join('.');
              parentDbId = pathToId[parentPath] || null;
            }
          }

          // Breadcrumb header'ı içeriğe ekle
          const breadcrumbHtml = page.breadcrumb
            ? `<div style="font-size:0.78rem;color:#888;margin-bottom:16px;padding-bottom:8px;border-bottom:1px solid rgba(255,255,255,0.08)">📁 ${page.breadcrumb}</div>`
            : '';

          const fullContent = breadcrumbHtml + (page.content || '');

          const result = await pool.query(
            `INSERT INTO notes (title, content, owner_group, created_by, parent_id, created_at, updated_at)
             VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
            [noteTitle, fullContent, targetGroup, req.user.email, parentDbId, page.created_at, page.updated_at]
          );

          // Bu sayfanın web path'ini → yeni DB id'sine eşle
          if (page.web) pathToId[page.web] = result.rows[0].id;
          results.imported++;
        } catch(e) {
          results.errors.push({ file: page.entryName, error: e.message });
          results.skipped++;
        }
      }

      res.json({ ok: true, message: `${results.imported} not içe aktarıldı, ${results.skipped} atlandı.`, ...results });
    } catch(e) {
      console.error('XAR import hatası:', e.message);
      res.status(500).json({ error: 'Import başarısız: ' + e.message });
    }
  });
});

// ── EXPORT: Tek Not ──────────────────────────────────────────
router.get('/note/:id', requireAuth, async (req, res) => {
  const { format = 'html' } = req.query;
  try {
    const result = await pool.query('SELECT * FROM notes WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const note = result.rows[0];
    if (!canRead(req.user, note)) return res.status(403).json({ error: 'Erişim yetkisi yok' });
    const filename = sanitize(note.title);
    switch(format) {
      case 'json':
        res.setHeader('Content-Disposition', `attachment; filename="${filename}.json"`);
        return res.json({ title: note.title, content: note.content, group: note.owner_group, exported_at: new Date().toISOString() });
      case 'md':
        res.setHeader('Content-Disposition', `attachment; filename="${filename}.md"`);
        res.setHeader('Content-Type', 'text/markdown');
        return res.send(toMarkdown(note.title, note.content));
      default:
        res.setHeader('Content-Disposition', `attachment; filename="${filename}.html"`);
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        return res.send(wrapHtml(note.title, note.content));
    }
  } catch(e) { res.status(500).json({ error: 'Export başarısız' }); }
});

// ── EXPORT: Grup ZIP ─────────────────────────────────────────
router.get('/group/:group', requireAuth, async (req, res) => {
  const { format = 'html' } = req.query;
  const group = req.params.group;
  if (!req.user.isAdmin && !req.user.isSuperAdmin && !req.user.groups.includes(group))
    return res.status(403).json({ error: 'Yetki yok' });
  try {
    const result = await pool.query('SELECT * FROM notes WHERE owner_group = $1 ORDER BY updated_at DESC', [group]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Not bulunamadı' });
    const zip = new AdmZip();
    const g   = sanitize(group);
    for (const note of result.rows) {
      const fn = sanitize(note.title);
      switch(format) {
        case 'json': zip.addFile(`${g}/${fn}.json`, Buffer.from(JSON.stringify({ title: note.title, content: note.content }, null, 2), 'utf8')); break;
        case 'md':   zip.addFile(`${g}/${fn}.md`,   Buffer.from(toMarkdown(note.title, note.content), 'utf8')); break;
        default:     zip.addFile(`${g}/${fn}.html`, Buffer.from(wrapHtml(note.title, note.content), 'utf8'));
      }
    }
    res.setHeader('Content-Disposition', `attachment; filename="notes-${g}.zip"`);
    res.setHeader('Content-Type', 'application/zip');
    res.send(zip.toBuffer());
  } catch(e) { res.status(500).json({ error: 'Export başarısız' }); }
});

// ── HELPERS ──────────────────────────────────────────────────
function wrapHtml(title, content) {
  return `<!DOCTYPE html><html lang="tr"><head><meta charset="UTF-8"/><title>${esc(title)}</title>
<style>body{font-family:-apple-system,sans-serif;max-width:860px;margin:40px auto;padding:0 24px;line-height:1.7;color:#222}
h1{font-size:2rem;border-bottom:2px solid #eee;padding-bottom:12px}
pre{background:#f6f8fa;padding:16px;border-radius:6px;overflow-x:auto}code{background:#f0f0f0;padding:2px 5px;border-radius:3px}
table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:8px 12px}th{background:#f0f4f8}
mark{background:#fff3cd;padding:1px 3px}img{max-width:100%}</style></head>
<body><h1>${esc(title)}</h1>${content}</body></html>`;
}

function toMarkdown(title, html) {
  let md = `# ${title}\n\n`;
  let c  = html
    .replace(/<h1[^>]*>(.*?)<\/h1>/gi, '# $1\n')
    .replace(/<h2[^>]*>(.*?)<\/h2>/gi, '## $1\n')
    .replace(/<h3[^>]*>(.*?)<\/h3>/gi, '### $1\n')
    .replace(/<strong[^>]*>(.*?)<\/strong>/gi, '**$1**')
    .replace(/<em[^>]*>(.*?)<\/em>/gi, '*$1*')
    .replace(/<code[^>]*>(.*?)<\/code>/gi, '`$1`')
    .replace(/<pre[^>]*><code[^>]*>([\s\S]*?)<\/code><\/pre>/gi, '```\n$1\n```\n')
    .replace(/<li[^>]*>(.*?)<\/li>/gi, '- $1\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>')
    .replace(/\n{3,}/g,'\n\n').trim();
  return md + c;
}

function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function sanitize(n) { return (n||'not').replace(/[/\\?%*:|"<>]/g,'-').replace(/\s+/g,'_').substring(0,100); }

function parseMultipart(body, boundary) {
  const parts = [];
  const sep   = Buffer.from(`--${boundary}`);
  const end   = Buffer.from(`--${boundary}--`);
  let start = 0;
  while (start < body.length) {
    const si = indexOf(body, sep, start);
    if (si === -1) break;
    if (body.slice(si, si + end.length).equals(end)) break;
    const hs = si + sep.length + 2;
    const he = indexOf(body, Buffer.from('\r\n\r\n'), hs);
    if (he === -1) break;
    const header = body.slice(hs, he).toString();
    const nm = header.match(/name="([^"]+)"/);
    const fn = header.match(/filename="([^"]+)"/);
    const ds = he + 4;
    const ns = indexOf(body, sep, ds);
    const de = ns === -1 ? body.length : ns - 2;
    parts.push({ name: nm ? nm[1] : '', filename: fn ? fn[1] : null, data: body.slice(ds, de) });
    start = ns === -1 ? body.length : ns;
  }
  return parts;
}

function indexOf(buf, search, offset = 0) {
  for (let i = offset; i <= buf.length - search.length; i++) {
    if (buf.slice(i, i + search.length).equals(search)) return i;
  }
  return -1;
}

module.exports = router;
