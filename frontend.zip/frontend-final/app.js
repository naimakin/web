process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
require('dotenv').config();

const express = require('express');
const session = require('express-session');
const { Issuer, generators } = require('openid-client');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const BACKEND_URL = process.env.BACKEND_URL || 'http://backend-service:4000';

const {
  OAUTH_CLIENT_ID,
  OAUTH_CLIENT_SECRET,
  OPENID_PROVIDER_URL,
  OPENID_REDIRECT_URI,
  WEBUI_AUTH_SIGNOUT_REDIRECT_URL,
  WEBUI_URL,
  LOG_LEVEL,
} = process.env;

const log = (...args) => { if (LOG_LEVEL === 'debug') console.log('[DEBUG]', ...args); };

// ── SESSION ────────────────────────────────────────────────
app.use(session({
  secret: OAUTH_CLIENT_SECRET || 'note-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 8 * 60 * 60 * 1000 },
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ── OIDC ───────────────────────────────────────────────────
let oidcClient;

async function initOIDC() {
  try {
    log('OIDC keşfediliyor:', OPENID_PROVIDER_URL);
    const issuer = await Issuer.discover(OPENID_PROVIDER_URL);
    oidcClient = new issuer.Client({
      client_id: OAUTH_CLIENT_ID,
      client_secret: OAUTH_CLIENT_SECRET,
      redirect_uris: [OPENID_REDIRECT_URI],
      response_types: ['code'],
    });
    log('OIDC hazır');
  } catch (err) {
    console.error('OIDC init hatası:', err.message);
    setTimeout(initOIDC, 5000);
  }
}

// ── AUTH MIDDLEWARE ────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.session.user) return next();
  if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Unauthorized' });
  res.redirect('/login');
}

// ── BACKEND PROXY MIDDLEWARE ───────────────────────────────
async function proxyToBackend(req, res) {
  try {
    const url = `${BACKEND_URL}${req.path}${req.url.includes('?') ? '?' + req.url.split('?')[1] : ''}`;
    const options = {
      method: req.method,
      headers: {
        'Content-Type': 'application/json',
        'X-User-Email': req.session.user.email,
        'X-User-Name': req.session.user.name,
        'X-User-Groups': JSON.stringify(req.session.user.groups || []),
        'X-Access-Token': req.session.user.access_token,
      },
    };
    if (req.method !== 'GET' && req.body) {
      options.body = JSON.stringify(req.body);
    }
    const backendRes = await fetch(url, options);
    const data = await backendRes.json();
    res.status(backendRes.status).json(data);
  } catch (err) {
    console.error('Backend proxy hatası:', err.message);
    res.status(502).json({ error: 'Backend ulaşılamıyor' });
  }
}

// ── ROUTES ────────────────────────────────────────────────
app.get('/', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/login', (req, res) => {
  if (!oidcClient) return res.status(503).send('Sistem hazırlanıyor, lütfen bekleyin ve sayfayı yenileyin.');
  const nonce = generators.nonce();
  const state = generators.state();
  req.session.nonce = nonce;
  req.session.state = state;
  const authUrl = oidcClient.authorizationUrl({ scope: 'openid email profile groups', nonce, state });
  log('Login redirect:', authUrl);
  res.redirect(authUrl);
});

app.get(['/callback', '/oauth/oidc/callback'], async (req, res) => {
  try {
    const params = oidcClient.callbackParams(req);
    const tokenSet = await oidcClient.callback(OPENID_REDIRECT_URI, params, {
      nonce: req.session.nonce,
      state: req.session.state,
    });
    const userinfo = await oidcClient.userinfo(tokenSet.access_token);
    log('Login başarılı:', userinfo.email, 'gruplar:', userinfo.groups);

    req.session.user = {
      name: userinfo.name || userinfo.preferred_username,
      email: userinfo.email,
      groups: userinfo.groups || [],
      access_token: tokenSet.access_token,
      id_token: tokenSet.id_token,
    };
    res.redirect('/');
  } catch (err) {
    console.error('Callback hatası:', err.message);
    res.redirect('/login');
  }
});

// Kullanıcı bilgisi
app.get('/api/me', requireAuth, (req, res) => {
  res.json({
    name: req.session.user.name,
    email: req.session.user.email,
    groups: req.session.user.groups || [],
  });
});

// Grup konfigürasyonu — frontend UI için (ConfigMap'ten okunur)
app.get('/api/groups', requireAuth, (req, res) => {
  let groupConfig = {};
  try {
    groupConfig = JSON.parse(process.env.GROUP_CONFIG || '{}');
  } catch(_) {}
  res.json({
    groups: groupConfig,
    adminGroup: process.env.ADMIN_GROUP || 'BTAOM_YONETICILER',
  });
});

// Backend proxy - tüm /api/notes/* istekleri backend'e gider
app.all('/api/notes*', requireAuth, proxyToBackend);
app.all('/api/diagrams*', requireAuth, proxyToBackend);
app.all('/api/admin*', requireAuth, proxyToBackend);
app.all('/api/export*', requireAuth, proxyToBackend);

// Import: multipart dosya yüklemesi için özel proxy
app.post('/api/import/xar', requireAuth, (req, res) => {
  const url = `${BACKEND_URL}/api/import/xar`;
  const headers = {
    'content-type': req.headers['content-type'],
    'X-User-Email': req.session.user.email,
    'X-User-Name': req.session.user.name,
    'X-User-Groups': JSON.stringify(req.session.user.groups || []),
  };
  const backendReq = require('http').request(url, { method: 'POST', headers }, (backendRes) => {
    res.status(backendRes.statusCode);
    backendRes.pipe(res);
  });
  backendReq.on('error', () => res.status(502).json({ error: 'Backend ulaşılamıyor' }));
  req.pipe(backendReq);
});

// Logout
app.get('/logout', (req, res) => {
  const idToken = req.session.user?.id_token;
  req.session.destroy();
  if (oidcClient && idToken) {
    try {
      const logoutUrl = oidcClient.endSessionUrl({
        id_token_hint: idToken,
        post_logout_redirect_uri: WEBUI_AUTH_SIGNOUT_REDIRECT_URL || WEBUI_URL || `http://localhost:${PORT}/login`,
      });
      return res.redirect(logoutUrl);
    } catch(e) {}
  }
  res.redirect('/login');
});

// Debug (geliştirme için)
app.get('/debug/token', requireAuth, (req, res) => {
  res.json({ name: req.session.user.name, email: req.session.user.email, groups: req.session.user.groups });
});

// ── START ──────────────────────────────────────────────────
initOIDC().then(() => {
  app.listen(PORT, () => console.log(`Frontend çalışıyor: http://localhost:${PORT}`));
});
